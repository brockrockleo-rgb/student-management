import {
  SafetyCertificateOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import type { CurrentUser, DataRecord, ResourceKey } from "../types";
import type { PermissionChecker, ResourceConfig } from "./dashboard.types";
import { roleLabels } from "./dashboard.utils";

type Props = {
  config: ResourceConfig;
  activeResource: ResourceKey;
  user: CurrentUser;
  currentClass?: DataRecord;
  rowsCount: number;
  can: PermissionChecker;
};

export default function DashboardOverview({
  config,
  activeResource,
  user,
  currentClass,
  rowsCount,
  can,
}: Props) {
  const actionCount = user.permissions.includes("*")
    ? 4
    : (["view", "create", "update", "delete"] as const).filter((action) =>
        can(action, activeResource),
      ).length;

  return (
    <>
      <div className="page-intro">
        <div>
          <p className="eyebrow">Hệ thống quản lý</p>
          <h1>{config.label}</h1>
          <p className="page-intro-description">{config.description}</p>
        </div>

        <div className="permission-badge">
          {currentClass ? (
            <>
              <strong>Lớp {String(currentClass.code)}:</strong>{" "}
              {String(currentClass.name)} · GVCN:{" "}
              {String(
                (currentClass.homeroomTeacher as DataRecord | undefined)
                  ?.name ?? "Chưa phân công",
              )}
            </>
          ) : (
            <>
              <strong>Quyền hiện tại:</strong>{" "}
              {user.permissions.includes("*")
                ? "Toàn quyền trên hệ thống"
                : user.permissions.join(", ")}
            </>
          )}
        </div>
      </div>

      {/* <div className="metric-grid">
        <article className="metric-card">
          <div className="metric-top">
            <span>Bản ghi đang hoạt động</span>
            <div className="metric-icon">{config.icon}</div>
          </div>
          <strong>{rowsCount}</strong>
        </article>

        <article className="metric-card">
          <div className="metric-top">
            <span>Vai trò</span>
            <div className="metric-icon">
              <UserOutlined />
            </div>
          </div>
          <strong className="metric-text">{roleLabels[user.position]}</strong>
        </article>

        <article className="metric-card">
          <div className="metric-top">
            <span>Quyền thao tác</span>
            <div className="metric-icon">
              <SafetyCertificateOutlined />
            </div>
          </div>
          <strong>{actionCount}</strong>
        </article>

        <article className="metric-card">
          <div className="metric-top">
            <span>Trạng thái</span>
            <div className="metric-icon">
              <TeamOutlined />
            </div>
          </div>
          <strong className="metric-text status-active">Hoạt động</strong>
        </article>
      </div> */}
    </>
  );
}
