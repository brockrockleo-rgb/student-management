import { App as AntApp, ConfigProvider } from "antd";
import { useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { getStoredUser } from "./api";
import Dashboard from "./Dashboard";
import LoginPage from "./LoginPage";
import type { CurrentUser } from "./types";

export default function App() {
  const [user, setUser] = useState<CurrentUser | null>(getStoredUser);
  return (
    <ConfigProvider theme={{ token: { colorPrimary: "#2464c7", borderRadius: 10, colorText: "#293b55", controlHeight: 40, fontFamily: "Arial, Helvetica, sans-serif" }, components: { Button: { fontWeight: 600 }, Table: { headerBg: "#fafbfd", rowHoverBg: "#f7faff" } } }}>
      <AntApp>
        {!user ? <LoginPage onLogin={setUser} /> : <Routes><Route path="/:resource" element={<Dashboard user={user} onLogout={() => setUser(null)} />} /><Route path="*" element={<Navigate to="/students" replace />} /></Routes>}
      </AntApp>
    </ConfigProvider>
  );
}
