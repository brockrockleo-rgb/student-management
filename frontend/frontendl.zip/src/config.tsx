import { ApartmentOutlined, IdcardOutlined, SafetyCertificateOutlined, TeamOutlined, UserOutlined } from "@ant-design/icons";
import type { ReactNode } from "react";
import type { FieldConfig, ResourceKey } from "./types";

export type ExcelConfig={
  exportFile: string;
  templateFile: string;
};

export type ResourceConfig = {
  label: string;
  menuLabel: string;
  singular: string;
  description: string;
  icon: ReactNode;
  endpoint: string;
  fields: FieldConfig[];
  columns: { key: string; label: string; kind?: "code" | "name" | "position" | "permission" }[];
    excel?:ExcelConfig;

};

const positionOptions = [
  { label: "Quản trị viên", value: "admin" },
  { label: "Giáo viên", value: "teacher" },
  { label: "Sinh viên", value: "student" },
];

export const resourceConfigs: Record<ResourceKey, ResourceConfig> = {
  students: {
    label: "Danh sách sinh viên", menuLabel: "Sinh viên", singular: "sinh viên", description: "Quản lý sinh viên theo lớp và giáo viên chủ nhiệm", icon: <IdcardOutlined />, endpoint: "/students",
    excel: {
  exportFile: "students.xlsx",
  templateFile: "student-import-template.xlsx",
},
    fields: [
      { key: "studentCode", label: "Mã sinh viên", required: true },
      { key: "name", label: "Họ và tên", required: true },
      { key: "email", label: "Email", type: "email", required: true },
      { key:"departmentId", label:"khoa", type:"select", required:true},
      { key: "classId", label: "Lớp", type: "select", required: true },
    ],
    columns: [
      { key: "studentCode", label: "Mã SV", kind: "code" }, { key: "name", label: "Họ và tên", kind: "name" },
      { key: "email", label: "Email" },
      {key: "schoolClass.department.name",label:"Khoa"},
      { key: "schoolClass.code", label: "Mã lớp", kind: "code" },
      { key: "schoolClass.name", label: "Tên lớp" },
      { key: "schoolClass.homeroomTeacher.teacherCode", label: "Mã GVCN", kind: "code" },
      { key: "schoolClass.homeroomTeacher.name", label: "Giáo viên chủ nhiệm" },
    ],
  },
  teachers: {
    label: "Danh sách giáo viên", menuLabel: "Giáo viên", singular: "giáo viên", description: "Quản lý hồ sơ và đơn vị công tác của giáo viên", icon: <TeamOutlined />, endpoint: "/teachers",

    excel: {
  exportFile: "teachers.xlsx",
  templateFile: "teacher-import-template.xlsx",
},
    fields: [
      { key: "teacherCode", label: "Mã giáo viên", required: true }, { key: "name", label: "Họ và tên", required: true },
      { key: "departmentId", label: "Khoa", type: "select", required: true },
    ],
    columns: [{ key: "teacherCode", label: "Mã GV", kind: "code" }, { key: "name", label: "Họ và tên", kind: "name" }, { key: "department.name", label: "Khoa" }],
  },
  departments: {
    label: "Danh sách khoa", menuLabel: "Khoa", singular: "khoa", description: "Quản lý các khoa và đơn vị đào tạo", icon: <ApartmentOutlined />, endpoint: "/departments",
    excel: {
  exportFile: "departments.xlsx",
  templateFile: "department-import-template.xlsx",
},
    fields: [{ key: "code", label: "Mã khoa", required: true }, { key: "name", label: "Tên khoa", required: true }],
    columns: [{ key: "code", label: "Mã khoa", kind: "code" }, { key: "name", label: "Tên khoa", kind: "name" }],
  },
  classes: {
    label: "Danh sách lớp", menuLabel: "Lớp", singular: "lớp", description: "Quản lý lớp, khoa và giáo viên chủ nhiệm", icon: <TeamOutlined />, endpoint: "/classes",
    excel: {
  exportFile: "classes.xlsx",
  templateFile: "class-import-template.xlsx",
},
    fields: [
      { key: "code", label: "Mã lớp", required: true }, { key: "name", label: "Tên lớp", required: true },
      { key: "departmentId", label: "Khoa", type: "select", required: true },
      { key: "teacherId", label: "Giáo viên chủ nhiệm", type: "select", required: true },
    ],
    columns: [
      { key: "code", label: "Mã lớp", kind: "code" }, { key: "name", label: "Tên lớp", kind: "name" },
      { key: "department.name", label: "Khoa" }, { key: "homeroomTeacher.teacherCode", label: "Mã giáo viên", kind: "code" },
      { key: "homeroomTeacher.name", label: "Giáo viên chủ nhiệm" },
    ],
  },




  users: {
  label: "Danh sach user",
  menuLabel: "User",
  singular: "tai khoan",
  description: "Tao tai khoan ",
  icon: <UserOutlined />,
  endpoint: "/users",

  fields: [
  { key: "position", label: "Vai tro", type: "select", options: positionOptions, required: true },
  { key: "referenceCode", label: "Ma SV / ma GV", required: true },
  { key: "username", label: "Ten dang nhap", required: true },
  { key: "name", label: "Ten hien thi", required: true },
  { key: "password", label: "Mat khau", type: "password", required: true },
],

  columns: [
    { key: "username", label: "Ten dang nhap", kind: "code" },
    { key: "name", label: "Ten hien thi", kind: "name" },
    { key: "position", label: "Vai tro", kind: "position" },
    { key: "referenceCode", label: "Ma lien ket" },
  ],
},
  permissions: {
    label: "phan quyen", menuLabel: "Phan Quyen", singular: "phan quyền", description: "chon user va cho phep cac quyen dc thuc hien", icon: <SafetyCertificateOutlined />, endpoint: "/permissions/users",
    fields: [],
    columns: [],
  },
};
