import { Form, Input, InputNumber, Modal, Select } from "antd";
import { useEffect } from "react";
import type { DataRecord, FieldConfig, Position } from "./types";

type Props = {
  open: boolean;
  singular: string;
  fields: FieldConfig[];
  record: DataRecord | null;
  readOnly: boolean;
  departments: DataRecord[];
  classes: DataRecord[];
  teachers: DataRecord[];
  onClose: () => void;
  onSave: (values: Record<string, unknown>) => Promise<void>;
};

export default function EntityModal({ open, singular, fields, record, readOnly, departments, classes, teachers, onClose, onSave }: Props) {
  const [form] = Form.useForm();
  const position = Form.useWatch<Position>("position", form);
  const departmentId = Form.useWatch<string>("departmentId", form);

  useEffect(() => {
  if (!open) return;

  form.resetFields();

  if (!record) return;

  const schoolClass=record.schoolClass as DataRecord|undefined;
  const schoolClassDepartment=schoolClass?.department as DataRecord|undefined;

  form.setFieldsValue({
    ...record,

    departmentId:
      (record.department as DataRecord | undefined)?.id ?? schoolClassDepartment,

    classId:
      (record.schoolClass as DataRecord | undefined)?.id,

    teacherId:
      (record.homeroomTeacher as DataRecord | undefined)?.id,

    referenceCode:
      (record.teacher as DataRecord | undefined)?.teacherCode ??
      (record.student as DataRecord | undefined)?.studentCode,

    password: undefined,
  });
}, [form, open, record]);

  // const visibleFields = fields.filter((field) => {
  //   if (field.key === "referenceCode") return position === "teacher" || position === "student";
  //   return true;
  // });
  const isStudentForm =
  fields.some(
    (field) => field.key === "studentCode"
  );
const onSelectedChange=(field:FieldConfig)=>{
  if(field.key!=="departmentId")
    return;
  if(isStudentForm){
    form.setFieldValue("classId",undefined);
  }
};

const isSelectDisabled=(field:FieldConfig)=>isStudentForm&& field.key==="classId"&& !departmentId;










  const isUserForm = fields.some((field) => field.key === "position");

const visibleFields = fields.filter(({ key }) => {
  if (!isUserForm) return true;
  if (["username", "name"].includes(key)) return position === "admin";
  if (key === "referenceCode") return ["teacher", "student"].includes(position);
  return true;
});

  const optionsFor = (field: FieldConfig) => {
    if (field.key === "departmentId") return departments.map((item) => ({ value: item.id, label: `${String(item.code)} - ${String(item.name)}` }));
    if (field.key === "classId") return classes.filter((item)=>Boolean(departmentId)&& (item.department as DataRecord|undefined)?.id===departmentId).map((item)=>({value:item.id, label:`${String(item.code)}-${String(item.name)}`,}));
    if (field.key === "teacherId") return teachers
      .filter((item) => !departmentId || (item.department as DataRecord | undefined)?.id === departmentId)
      .map((item) => ({ value: item.id, label: `${String(item.teacherCode)} - ${String(item.name)}` }));
    return field.options;
  };

  return (
    <Modal
      title={`${record ? (readOnly ? "Chi tiết" : "Cập nhật") : "Tạo"} ${singular}`}
      open={open}
      onCancel={onClose}
      onOk={() => form.validateFields().then(onSave)}
      okText={record ? "Lưu thay đổi" : "Tạo mới"}
      cancelText="Đóng"
      okButtonProps={{ style: readOnly ? { display: "none" } : undefined }}
      forceRender
    >
      {readOnly && <div className="modal-hint">Bạn có quyền xem nhưng không có quyền chỉnh sửa dữ liệu này.</div>}

      {isUserForm &&
  (position === "teacher" ||
    position === "student") && (
    <div className="modal-hint">
      {record
      ?(<>
      ten dang nhap:{" "}
      <strong>{String(record.username)}</strong>
      {"-"}
      ten hien thi:{" "}
      <strong>{String(record.name)}</strong>
      </>):(<>
      Ten dang nhap va ten hien thij tao tu dong
      <br/>
      Sinh vien:
      <strong>{"username=mssv"}</strong>
      <br/>
      Giao vien:
      <strong>{"username=ma giao vien"}</strong>
      </>)}

    </div>
  )}
      




      <Form form={form} layout="vertical" disabled={readOnly} preserve={false}>
  {visibleFields.map((field) => {
    let label = field.label;
    if (isUserForm && field.key === "referenceCode") {
      if (position === "student") label = "Ma sinh vien";
      if (position === "teacher") label = "Ma giao vien";
    }

    const lowerLabel = label.toLowerCase();
    const required =
      field.key === "referenceCode"
        ? position !== "admin"
        : field.required && !(record && field.key === "password");

    return (
      <Form.Item
        key={field.key}
        name={field.key}
        label={label}
        rules={required ? [{ required: true, message: `Nhap ${lowerLabel}` }] : undefined}
      >
        {field.type === "select" ? (
          <Select
            options={optionsFor(field)}
            disabled={isSelectDisabled(field)}
            placeholder={
              isStudentForm && field.key === "classId" && !departmentId
                ? "Chon khoa truoc"
                : `Chon ${lowerLabel}`
            }
          />
        ) : field.type === "number" ? (
          <InputNumber min={1} max={10} style={{ width: "100%" }} />
        ) : field.type === "password" ? (
          <Input.Password
            placeholder={record ? "De trong neu khong doi mat khau" : `Nhap ${lowerLabel}`}
          />
        ) : (
          <Input
            type={field.type === "email" ? "email" : "text"}
            placeholder={`Nhap ${lowerLabel}`}
          />
        )}
      </Form.Item>
    );
  })}
</Form>
    </Modal>
  );
}
