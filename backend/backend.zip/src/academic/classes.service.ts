import { BadRequestException, Injectable } from "@nestjs/common";
import { InjectRepository } from "@mikro-orm/nestjs";
import { EntityManager, EntityRepository } from "@mikro-orm/mongodb";
import { EntityUtilsService } from "../common";
import { ClassDto } from "../dtos";
import { Department, SchoolClass, Teacher } from "../entities";
import type { JwtUser } from "../security";
import { AcademicAccessService } from "./academic-access.service";

@Injectable()
export class ClassesService {
  constructor(
    private readonly em: EntityManager,
    private readonly access: AcademicAccessService,
    private readonly entityUtils: EntityUtilsService,
    @InjectRepository(SchoolClass)
    private readonly classes: EntityRepository<SchoolClass>,
    @InjectRepository(Department)
    private readonly departments: EntityRepository<Department>,
    @InjectRepository(Teacher)
    private readonly teachers: EntityRepository<Teacher>,
  ) {}

  async list(jwt: JwtUser) {
    const classIds = await this.access.accessibleClassIds(jwt);
    const scope = classIds === null ? {} : { _id: { $in: classIds } };
    return this.classes.find(
      { deleted: false, ...scope },
      {
        populate: ["department", "homeroomTeacher"],
        orderBy: { createdAt: "ASC" },
      },
    );
  }

  async create(dto: ClassDto) {
    const { department, homeroomTeacher } = await this.resolveRelations(dto);
    const entity = this.classes.create({
      code: dto.code,
      name: dto.name,
      department,
      homeroomTeacher,
    });
    this.em.persist(entity);
    await this.em.flush();
    return entity;
  }

  async update(id: string, dto: ClassDto) {
    const entity = await this.entityUtils.getActive(this.classes, id, "lớp");
    const { department, homeroomTeacher } = await this.resolveRelations(dto);
    entity.code = dto.code;
    entity.name = dto.name;
    entity.department = department;
    entity.homeroomTeacher = homeroomTeacher;
    await this.em.flush();
    return entity;
  }

  delete(ids: string[]) {
    return this.entityUtils.softDelete(this.classes, ids);
  }

  private async resolveRelations(dto: ClassDto) {
    const department = await this.entityUtils.getActive(
      this.departments,
      dto.departmentId,
      "khoa",
    );
    const homeroomTeacher = await this.entityUtils.getActive(
      this.teachers,
      dto.teacherId,
      "giáo viên chủ nhiệm",
    );
    await this.em.populate(homeroomTeacher, ["department"]);
    this.assertSameDepartment(department, homeroomTeacher);
    return { department, homeroomTeacher };
  }

  private assertSameDepartment(department: Department, teacher: Teacher) {
    if (
      !teacher.department ||
      teacher.department.deleted ||
      teacher.department.id !== department.id
    ) {
      throw new BadRequestException(
        "Giáo viên chủ nhiệm phải thuộc khoa của lớp",
      );
    }
  }
}
