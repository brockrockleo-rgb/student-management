import { Injectable, OnApplicationBootstrap } from "@nestjs/common";
import { EntityManager, MikroORM } from "@mikro-orm/mongodb";
import * as bcrypt from "bcryptjs";
import {
  Department, Permission, Position,
  SchoolClass, Student, Teacher, User, UserPermission // Đã xóa PositionPermission
} from "./entities";

const resources = ["students", "teachers", "departments", "classes", "users", "permissions"];
const actions = ["view", "create", "update", "delete"];

const DEFAULT_PERMISSION_CODES = {
  [Position.STUDENT]: ["students.view"],
  [Position.TEACHER]: ["students.view", "students.create", "students.update", "students.delete", "classes.view"],
  [Position.ADMIN]: []
};

@Injectable()
export class BootstrapService implements OnApplicationBootstrap {
  constructor(private readonly orm: MikroORM) {}

  async onApplicationBootstrap() {
    const em = this.orm.em.fork();
    const admin = await em.findOne(User, { username: "admin" });

    if (admin) {
      await this.migrateExistingData(em);
    } else {
      await this.seedNewDatabase(em);
    }

    await this.ensureFixedPermissions(em);
    await em.flush();

    await this.ensureUserPermissionDefaults(em);
    await em.flush();

  }

  private async seedNewDatabase(em: EntityManager) {
    const cntt = em.create(Department, { code: "CNTT", name: "Khoa Công nghệ thông tin" });
    const dtvt = em.create(Department, { code: "DTVT", name: "Khoa Điện tử - Viễn thông" });

    const teacher1 = em.create(Teacher, { teacherCode: "GV001", name: "Nguyễn Văn Hùng", department: cntt });
    const teacher2 = em.create(Teacher, { teacherCode: "GV002", name: "Trần Minh Lan", department: dtvt });

    const ktmt = em.create(SchoolClass, {
      code: "KTMT01", name: "Kỹ thuật máy tính 01", department: cntt, homeroomTeacher: teacher1,
    });
    const dtvtClass = em.create(SchoolClass, {
      code: "DTVT01", name: "Điện tử - Viễn thông 01", department: dtvt, homeroomTeacher: teacher2,
    });

    const student1 = em.create(Student, {
      studentCode: "20210001", name: "Nguyễn Minh An", email: "an.nm@hust.edu.vn", schoolClass: ktmt,
    });
    em.create(Student, {
      studentCode: "20210002", name: "Trần Thu Bình", email: "binh.tt@hust.edu.vn", schoolClass: dtvtClass,
    });

    em.create(User, {
      username: "admin", passwordHash: await bcrypt.hash("admin123", 12),
      name: "Quản trị hệ thống", position: Position.ADMIN,
      permissionsInitialized: false,
    });
    em.create(User, {
      username: "teacher1", passwordHash: await bcrypt.hash("teacher123", 12),
      name: teacher1.name, position: Position.TEACHER, teacher: teacher1,
      permissionsInitialized: false,
    });
    em.create(User, {
      username: "student1", passwordHash: await bcrypt.hash("student123", 12),
      name: student1.name, position: Position.STUDENT, student: student1,
      permissionsInitialized: false,
    });
  }

  private async migrateExistingData(em: EntityManager) {
    const classes = await em.find(SchoolClass, { deleted: false }, { populate: ["department"] });
    const teachers = await em.find(Teacher, { deleted: false }, { populate: ["department"] });

    for (const schoolClass of classes) {
      if (!schoolClass.homeroomTeacher) {
        schoolClass.homeroomTeacher = teachers.find(
          (teacher) => teacher.department.id === schoolClass.department.id,
        );
      }
    }

    const oldPermissions = await em.find(Permission, { deleted: false });
    oldPermissions
      .filter((permission) => permission.code.startsWith("subjects.") || permission.code.startsWith("assignments."))
      .forEach((permission) => { permission.deleted = true; });
  }

  private async ensureFixedPermissions(em: EntityManager) {
    const allFixedCodes = ["permissions.manage"];
    for (const resource of resources) {
      for (const action of actions) {
        allFixedCodes.push(`${resource}.${action}`);
      }
    }

    for (const code of allFixedCodes) {
      const existing = await em.findOne(Permission, { code, deleted: false });
      if (!existing) {
        const perm = em.create(Permission, {
          code,
          name: code,
          description: `Quyền hệ thống: ${code}`,
        });
        em.persist(perm);
      }
    }
  }

  private async ensureUserPermissionDefaults(em: EntityManager) {
    const users = await em.find(User, { deleted: false });

    for (const user of users) {
      if (user.permissionsInitialized) continue;

      const defaultCodes = new Set<string>(
        user.position === Position.ADMIN ? [] : (DEFAULT_PERMISSION_CODES[user.position] ?? [])
      );

      const existingMappings = await em.find(
        UserPermission,
        { user: user._id },
        { populate: ["permission"] }
      );

      const mappingByCode = new Map<string, UserPermission>();
      for (const mapping of existingMappings) {
        const code = mapping.permission.code;
        mappingByCode.set(code, mapping);
        mapping.deleted = !defaultCodes.has(code);
      }

      if (defaultCodes.size > 0) {
        const permissionsToAssign = await em.find(Permission, {
          code: { $in: Array.from(defaultCodes) },
          deleted: false,
        });

        for (const permission of permissionsToAssign) {
          const existing = mappingByCode.get(permission.code);
          if (existing) {
            existing.deleted = false;
            continue;
          }

          em.persist(em.create(UserPermission, {
            user,
            permission,
            deleted: false,
          }));
        }
      }

      user.permissionsInitialized = true;
      em.persist(user);
    }
  }
}