import { CanActivate, ExecutionContext, Injectable, SetMetadata, UnauthorizedException } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@mikro-orm/nestjs";
import { EntityRepository, ObjectId } from "@mikro-orm/mongodb";
import { Position, UserPermission } from "./entities";

export const IS_PUBLIC_KEY = "isPublic";
export const PERMISSIONS_KEY = "permissions";
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
export const RequirePermissions = (...permissions: string[]) => SetMetadata(PERMISSIONS_KEY, permissions);

export type JwtUser = {
  sub: string;
  username: string;
  name: string;
  position: Position;
  teacherId?: string;
  studentId?: string;
  referenceCode?: string;
};

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, private readonly jwt: JwtService) {}

  async canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(), 
      context.getClass()
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest();
    const [type, token] = request.headers.authorization?.split(" ") ?? [];
    if (type !== "Bearer" || !token) throw new UnauthorizedException("Bạn chưa đăng nhập");

    try {
      request.user = await this.jwt.verifyAsync<JwtUser>(token);
      return true;
    } catch {
      throw new UnauthorizedException("Token không hợp lệ hoặc đã hết hạn");
    }
  }
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    @InjectRepository(UserPermission) 
    private readonly userPermissions: EntityRepository<UserPermission>,
  ) {}

  async canActivate(context: ExecutionContext) {
    const required = this.reflector.getAllAndOverride<string[]>(PERMISSIONS_KEY, [
      context.getHandler(), 
      context.getClass()
    ]);

    if (!required?.length) return true;

    const user = context.switchToHttp().getRequest().user as JwtUser;

    if (user.position === Position.ADMIN) {
      return true;
    }

    const mappings = await this.userPermissions.find(
      {
        user: new ObjectId(user.sub),
        deleted: false,
      } as never,
      {
        populate: ["permission"] as never,
      },
    );

    const available = new Set(
      mappings.map((item: any) => item.permission.code)
    );

    return required.every((permission) => available.has(permission));
  }
}